#This the source code for MATH4432 project 3
#Xingbo SHANG 20256071

# Read the result from the image training_1 as training set for the model
directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/training and validation/training_'
data.training = read.csv(paste(directory,as.character(1),'.csv',sep = ''),header = FALSE)
#Read the rsult from the image training_2 as validation set for model optimization
data.validation = read.csv(paste(directory,as.character(2),'.csv',sep = ''),header = FALSE)
#Name the column of the training set and validation set.
colnames(data.training) = c('Row','Col','Intensity','Gradient','Environment','Result')
colnames(data.validation) = c('Row','Col','Intensity','Gradient','Environment','Result')
data.training$Result = as.factor(data.training$Result)
fix(data.training)

library(e1071)
library(tictoc)
#Optimize SVM with linear kernel
#~4 min to finish (The time is for my laptop with 8G RAM and CORE i7 7500 CPU)
image.directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/linear kernel svm/'
tic()
for (i in c(0.1,1,10,100))
{
  svm.fit = svm(Result~.,data = data.training,kernel = 'linear',cost = i)
  svm.predict = predict(svm.fit,data.validation)
  svm.predict = as.numeric(svm.predict)
  svm.predict = svm.predict-1
  cmatrix = table(predict = svm.predict, referencce = data.validation$Result)
  print(paste('cmatrix for linear kernel with cost =',as.character(i),sep = ' '))
  print(cmatrix)
  reference.image = matrix(data.validation$Result,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
  svm.image = matrix(svm.predict,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
  svm_reference.image = svm.image
  svm_reference.image[svm_reference.image!=reference.image] = 2
  image.name = paste('SVM with cost =',as.character(i),sep = ' ')
  jpeg(paste(image.directory,image.name,'.jpg',sep = ''),width = 1160, height = 530)
  par(mfrow = c(1,3))
  image(t(reference.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
        main = 'Unsupervised learning')
  image(t(svm.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
        main = image.name)
  image(t(svm_reference.image), useRaster = TRUE,col = c('black','white','red'),ylim = c(1,0),
        main = 'Overlapped with diagreement highlighted')
  dev.off()
}
toc()

#Which feature helps identify parts of the cell that unsupervised learning fails to identify?
svm.fit.excluded = svm(Result~.-Row-Col,data = data.training, kernel = 'linear',cost = 0.1)
svm.predict.excluded = predict(svm.fit.excluded, data.validation)
svm.predict.excluded = as.numeric(svm.predict.excluded)
svm.predict.excluded = svm.predict.excluded-1
svm.image.excluded = matrix(svm.predict.excluded,nrow = max(data.training$Row),ncol = max(data.training$Col))
image(t(svm.image.excluded),useRaster = TRUE,col = c('black','white'),ylim = c(1,0),main = 'Result from svm after excluding row and column')

#Visualize support vectors
svm.fit = svm(Result~.,data = data.training, kernel = 'linear',cost = 0.1)
svm.predict = predict(svm.fit, data.training)
svm.predict = as.numeric(svm.predict)
svm.predict = svm.predict-1
svm.predict[svm.fit$index] = 2
svm.image = matrix(svm.predict,nrow = max(data.training$Row),ncol = max(data.training$Col))
image(t(svm.image),useRaster = TRUE,col = c('black','white','red'),ylim = c(1,0),main = 'Visualization of support vectors')


#SVM with nonlinear kernel

#Optimize SVM with radial kernel
#~1.5 hours to finish
image.directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/polynomial kernel svm/'
tic()
for (i in c(0.1,1,10,100))
{
  for(j in c(0.5,1,2,3,4))
  {
    svm.fit = svm(Result~.,data = data.training, kernel = 'radial',cost = i,gamma = j)
    svm.predict = predict(svm.fit,data.validation)
    svm.predict = as.numeric(svm.predict)
    svm.predict = svm.predict-1
    cmatrix = table(predict = svm.predict, referencce = data.validation$Result)
    print(paste('cmatrix for radial kernel with cost =',as.character(i),'gamma =',as.character(j),sep = ' '))
    print(cmatrix)
    reference.image = matrix(data.validation$Result,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
    svm.image = matrix(svm.predict,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
    svm_reference.image = svm.image
    svm_reference.image[svm_reference.image!=reference.image] = 2
    image.name = paste('SVM with cost =',as.character(i),'gamma =',as.character(j),sep = ' ')
    jpeg(paste(image.directory,image.name,'.jpg',sep = ''),width = 1160, height = 530)
    par(mfrow = c(1,3))
    image(t(reference.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
          main = 'Unsupervised learning')
    image(t(svm.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
          main = image.name)
    image(t(svm_reference.image), useRaster = TRUE,col = c('black','white','red'),ylim = c(1,0),
          main = 'Overlapped with diagreement highlighted')
    dev.off()
  }
}
toc()

#SVM with polynomial kernel
#~3.5 hours to finish
image.directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/polynomial kernel svm/'
tic()
for (i in c(4))
{
  for (j in c(0.1,1,10))
  {
    for(k in c(0.1,0.5,1))
    {
      svm.fit = svm(Result~.,data = data.training, kernel = 'polynomial',degree = i,cost = j,gamma = k)
      svm.predict = predict(svm.fit,data.validation)
      svm.predict = as.numeric(svm.predict)
      svm.predict = svm.predict-1
      cmatrix = table(predict = svm.predict, referencce = data.validation$Result)
      print(paste('cmatrix for polynomial kernel with degree =',as.character(i), 'cost =',as.character(j),'gamma =',as.character(k),sep = ' '))
      print(cmatrix)
      reference.image = matrix(data.validation$Result,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
      svm.image = matrix(svm.predict,nrow = max(data.validation$Row),ncol = max(data.validation$Col))
      svm_reference.image = svm.image
      svm_reference.image[svm_reference.image!=reference.image] = 2
      image.name = paste('Degree',as.character(i),'SVM with cost =',as.character(j),'gamma =',as.character(k),sep = ' ')
      jpeg(paste(image.directory,image.name,'.jpg',sep = ''),width = 1160, height = 530)
      par(mfrow = c(1,3))
      image(t(reference.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
            main = 'Unsupervised learning')
      image(t(svm.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
            main = image.name)
      image(t(svm_reference.image), useRaster = TRUE,col = c('black','white','red'),ylim = c(1,0),
            main = 'Overlapped with diagreement highlighted')
      dev.off()
    }
  }
}
toc()

#The best model was found to be svm with radial kernel and cost = 1, gamma = 2
svm.fit = svm(Result~.,data = data.training, kernel = 'radial',cost = 1,gamma = 2)

#Test the svm with three more images
data.test = list(3)
directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/test/test_'
for(n in 1:3)
{
  data.test[[n]] = read.csv(paste(directory,as.character(n),'.csv',sep = ''),header = FALSE)
  colnames(data.test[[n]]) = c('Row','Col','Intensity','Gradient','Environment','Result')
}

image.directory = 'C:/Users/Xingbo SHANG/Desktop/HKUST courses/MATH4432/project3/test result/'
for(n in 1:3)
{
  svm.predict=predict(svm.fit, data.test[[n]])
  svm.predict=as.numeric(svm.predict)
  svm.predict=svm.predict-1
  reference.image = matrix(data.test[[n]]$Result,nrow = max(data.test[[n]]$Row),ncol = max(data.test[[n]]$Col))
  svm.image = matrix(svm.predict,nrow = max(data.test[[n]]$Row),ncol = max(data.test[[n]]$Col))
  svm_reference.image = svm.image
  svm_reference.image[svm_reference.image!=reference.image] = 2
  image.name = paste('Result from svm for test',as.character(n),sep = ' ')
  jpeg(paste(image.directory,image.name,'.jpg',sep = ''),width = 1160, height = 530)
  par(mfrow = c(1,3))
  image(t(reference.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
        main = 'Unsupervised learning')
  image(t(svm.image), useRaster = TRUE,col = c('black','white'),ylim = c(1,0),
        main = image.name)
  image(t(svm_reference.image), useRaster = TRUE,col = c('black','white','red'),ylim = c(1,0),
        main = 'Overlapped with diagreement highlighted')
  dev.off()
}
