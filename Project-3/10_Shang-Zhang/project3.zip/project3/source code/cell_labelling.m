%% Read the image to be segmented
directory = 'C:\Users\Xingbo SHANG\Desktop\HKUST courses\MATH4432\project3';
index = 2;
image = imread(strcat(directory,'\','test_',num2str(index),'.tif'));
disp(strcat('Reading training_',num2str(index)));
image = image(2:511,:);
imshow(image,[5000,15000]);
%% Marker identification
se = strel('disk',8);
gray_eroded = imerode(image,se);
gray_reconstructed = imreconstruct(gray_eroded,image);
marker = imregionalmax(gray_reconstructed);
marker_overlapped = image;
marker_overlapped(marker == 1) = 10000;
imshow(marker_overlapped, [5000,15000]);
%% Background identifictaion (part 1);
bw = imbinarize(image, 'adaptive');
bw = bwareaopen(bw,100);
figure,imshow(bw);
%% Background identifictaion (part 2);
se = strel('disk',50);
bg_identifier = ~imdilate(bw, se);
bg_overlapped = image;
bg_overlapped(bg_identifier == 1) = 0;
imshow(bg_overlapped, [5000, 15000]);
%% Marker controllled watershed
ws_input = imcomplement(image);
ws_input = imimposemin(ws_input, bg_identifier|marker);
ws_output = watershed(ws_input);
ws_overlapped = image;
ws_overlapped(ws_output == 0) = 15000;
imshow(ws_overlapped, [5000,15000]);
%% Two component Gaussian mixture model for shrinking the result from water shed.
final_mask = zeros(size(image));
for n = 2:max(ws_output(:))
    if(isempty(image(marker == 1 & ws_output == n)))
        continue;
    end
    intensity = image(ws_output == n);
    intensity = single(intensity);
    gm.fit = fitgmdist(intensity,2);
    gm.cluster = cluster(gm.fit,intensity);
    %
    intensity(gm.cluster == 1) = 0;
    intensity(gm.cluster == 2) = 1;
    temporary_result_1 = zeros(size(image));
    temporary_result_1(ws_output == n) = intensity;
    intensity(gm.cluster == 2) = 0;
    intensity(gm.cluster == 1) = 1;
    temporary_result_2 = zeros(size(image));
    temporary_result_2(ws_output == n) = intensity;
    %
    overlap_1 = sum(temporary_result_1(marker == 1 & temporary_result_1 == 1));
    overlap_2 = sum(temporary_result_2(marker == 1 & temporary_result_2 == 1));
    %
    if(overlap_1>overlap_2)
        final_mask(temporary_result_1 == 1) =1;
    else
        final_mask(temporary_result_2 == 1) =1;
    end
end
final_mask = imbinarize(final_mask);
final_mask = bwareaopen(final_mask,100);
imshow(final_mask);
%% Extract feartues of background and cell based on the final mask
[nrow,ncol] = size(image);
num_piexels = nrow*ncol;
num_features = 5;
training_data = zeros(num_piexels,num_features+1);
%% The first and second column stores the row and column index of each piexel.
for n = 1:ncol
    start = nrow*(n-1)+1;
    training_data(start:start+nrow-1,1) = 1:nrow;
    training_data(start:start+nrow-1,2) = n;
end
%% The thrid column stores the scaled intensity of each image.
scaled_image = double(image)/double(min(image(:)));
training_data(:,3) = scaled_image(:);
%% The fourth column stores the magnitude of gradient of each pixel.
[Gmag,Gdir] = imgradient(scaled_image);
training_data(:,4) = Gmag(:);
%% The fifth column stores the 'environment' of each pixel defined by the kernel. 
kernel = [1/8,1/8,1/8;1/8,0,1/8;1/8,1/8,1/8];
filtered_image = imfilter(scaled_image,kernel,'replicate');
training_data(:,5) = filtered_image(:);
%% The sixth column stores whether the pixel is regarded as cell or background.
% 1 -> cell, 0->backgroubd
training_data(:,6) = final_mask(:);
%% Output the training data in csv.
csvwrite(strcat('test_',num2str(index),'.csv'), training_data);
%%
imshow(final_mask);
h=getframe;
filepath = 'C:\Users\Xingbo SHANG\Desktop\HKUST courses\MATH4432\project3\';
filename = 'Result from unsupervised learning.tif';
imwrite(h.cdata,strcat(filepath,filename));